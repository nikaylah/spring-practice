package com.mongo.exception;

public class StudentAlreadyExistsException extends Exception {

	public StudentAlreadyExistsException(String string) {
		// TODO Auto-generated constructor stub
	}
}
