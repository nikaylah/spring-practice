package com.mongo.exception;

public class StudentNotFoundException extends Exception {

	public StudentNotFoundException(String string) {
		// TODO Auto-generated constructor stub
	}
}
